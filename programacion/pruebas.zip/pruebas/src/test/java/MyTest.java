import org.junit.Assert;
import org.junit.Test;

public class MyTest {

    @Test
    public void prueba() {
        Assert.assertEquals(1, 1);
    }
}
